% despliega(Tablero).
% despliega un tablero en pantalla

despliega(A/B/C/D/E/F/G/H/I):-
    pon(A),pon('|'),pon(B),pon('|'),pon(C),nl,
    pon('------'),nl,
    pon(D),pon('|'),pon(E),pon('|'),pon(F),nl,
    pon('------'),nl,
    pon(G),pon('|'),pon(H),pon('|'),pon(I),nl,!.

% pon(X).
% escribe un caracter si no es variable

pon(X):-nonvar(X),write(X).
pon(X):-var(X),write(' ').

% arriba(Tablero, NT)
% NT is Tablero haciendo movientos arriba

arriba(A/B/C/D/E/F/G/H/I, D/B/C/A/E/F/G/H/I):-
    var(D).
arriba(A/B/C/D/E/F/G/H/I, A/E/C/D/B/F/G/H/I):-
    var(E).
arriba(A/B/C/D/E/F/G/H/I, A/B/F/D/E/C/G/H/I):-
    var(F).
arriba(A/B/C/D/E/F/G/H/I, A/B/C/G/E/F/D/H/I):-
    var(G).
arriba(A/B/C/D/E/F/G/H/I, A/B/C/D/H/F/G/E/I):-
    var(H).
arriba(A/B/C/D/E/F/G/H/I, A/B/C/D/E/I/G/H/F):-
    var(I).

abajo(A/B/C/D/E/F/G/H/I, D/B/C/A/E/F/G/H/I):-
    var(A).
abajo(A/B/C/D/E/F/G/H/I, A/E/C/D/E/F/G/H/I):-
    var(B).
abajo(A/B/C/D/E/F/G/H/I, A/B/F/D/E/C/G/H/I):-
    var(C).
abajo(A/B/C/D/E/F/G/H/I, A/B/C/G/E/F/D/H/I):-
    var(D).
abajo(A/B/C/D/E/F/G/H/I, A/B/C/D/H/F/G/E/I):-
    var(E).
abajo(A/B/C/D/E/F/G/H/I, A/B/C/D/E/I/G/H/F):-
    var(F).

derecha(A/B/C/D/E/F/G/H/I, B/A/C/D/E/F/G/H/I):-
    var(A).
derecha(A/B/C/D/E/F/G/H/I, A/C/B/D/E/F/G/H/I):-
    var(B).
derecha(A/B/C/D/E/F/G/H/I, A/B/C/E/D/F/G/H/I):-
    var(D).
derecha(A/B/C/D/E/F/G/H/I, A/B/C/D/F/E/G/H/I):-
    var(E).
derecha(A/B/C/D/E/F/G/H/I, A/B/C/D/E/F/H/G/I):-
    var(G).
derecha(A/B/C/D/E/F/G/H/I, A/B/C/D/E/F/G/I/H):-
    var(H).

izquierda(A/B/C/D/E/F/G/H/I, B/A/C/D/E/F/G/H/I):-
    var(B).
izquierda(A/B/C/D/E/F/G/H/I, A/C/B/D/E/F/G/H/I):-
    var(C).
izquierda(A/B/C/D/E/F/G/H/I, A/B/C/E/D/F/G/H/I):-
    var(E).
izquierda(A/B/C/D/E/F/G/H/I, A/B/C/D/F/E/G/H/I):-
    var(F).
izquierda(A/B/C/D/E/F/G/H/I, A/B/C/D/E/F/H/G/I):-
    var(G).
izquierda(A/B/C/D/E/F/G/H/I, A/B/C/D/E/F/G/I/H):-
    var(I).

proximo(Tablero, ST):-
    arriba(Tablero, ST).
proximo(Tablero, ST):-
    abajo(Tablero, ST).
proximo(Tablero, ST):-
    izquierda(Tablero, ST).
proximo(Tablero, ST):-
    derecha(Tablero, ST).
member(X,[X|Xs]).
member(X,[Y|Ys]):-
	member(X,Ys).

 
ultimo(A/B/C/D/E/F/G/H/I):-
    nonvar(A), nonvar(B), nonvar(C), nonvar(D), nonvar(E), nonvar(F), nonvar(G), nonvar(H), var(I).
%Pasan cosas raras por aqui, porque los movimientos de, Izquierda, Derecha, Arriba y Abajo se hacen bien, si se ejecutan por aparte
%en la recursividad con el muestra que si esta haciendo los movimientos, pero ha de faltar algo para que funcione bien
res_acertijo(Ini, Sol):-
    hazbusca([Ini], [], Sol).

hazbusca([Sol|_], Evi, Sol):- ultimo(Sol). %caso base


hazbusca([Edo|Resto], Sol, Vis):-
    %findall encontrar todas las soluciones posibles de proximo
    findall(Nuevo, (proximo(Edo, Nuevo), \+ member(Nuevo, Vis)), Nuevos), %Nuevos es una lista de los estados que se pueden llegar desde Edo
    append(Nuevos, Vis, NuevasVis),
    append(Resto, Nuevos, NuevaLista),
    hazbusca(NuevaLista, Sol, NuevasVis).
