--Bolaños Gracida Giovanni Andrik 2193054547
--1 Haskell:
mcd a 0 = a
mcd a b = mcd b (mod a b)
coprimos a 0 = "No es coprimo" -- caso base cuando b es igual a 0
coprimos 0 b = "No es coprimo" -- caso base cuando a es igual a 0
coprimos a b = if mcd a b == 1 then "Es coprimo" else  "No es coprimo" -- compara si el mcd de dos numeros es igual a 1, si es asi es coprimo


--2:
tirax :: Eq a => a -> [a] -> [a]
tirax x [] = []
tirax x (y:ys) = if x == y then tirax x ys else y : tirax x ys--se eliminan los elementos repetidos de uan lista
contar x xs = length xs - length (tirax x xs)--tamaño de los elementos eliminados
codifica [] = []--caso base
codifica (x:xs) = (contar x (x:xs), x) : codifica (tirax x xs)  --se devuelve una lista de tuplas en donde 
                                                                --se muestra el elemnto y cuantas veces aparece 
------------------------------------
--1 AVANZADO:
data Fracciones  = Fr Int Int  deriving (Eq)--tipo de dato 
suma (Fr a b) (Fr c d) = Fr (a * d + b * c) (b * d)--suma
resta (Fr a b) (Fr c d) = Fr (a * d - b * c) (b * d)--resta
multiplicacion (Fr a b) (Fr c d) = Fr (a*c) (b *d)--Multiplicacion
division (Fr a b) (Fr c d) = Fr (a*d) (b *c) --division con Fr

normal (Fr a b) =  listaPrimos a 
instance Show Fracciones where
    show (Fr a b) = show a ++ " / " ++ show b --mjs que se mostrara en consola

primo n = [x | x <- [1..n], n `mod` x == 0] --buscamnos los numeros divisibles 
listaPrimos n = [x | x <- [2..n], primo x == [1,x]] --obtenemos una lista de primos existe en el rango de 2..n

--------------------
--3
mezcla [] ys = ys--primer caso base cuando la lista xs es vacia
mezcla xs [] = xs--segundo caso base cuando la lista ys es vacia
mezcla (x:xs) (y:ys) 
    | x <= y = x : mezcla xs (y:ys) --  se agrega x  a la lista cuando x <=y
    | otherwise = y : mezcla (x:xs) ys -- si x es mayor y se agrega a la lista
mS [] = [] --caso base cuando la lista es vacia
mS [x] = [x]--cuando  se tiene un solo elemento se regresa ese elemnto
mS xs = mezcla (mS izq) (mS der) --funcion recursiva usando la funcion mezcla para poder ordenar los valores
    where 
        mitad = length xs `div` 2 --Dividimos la lista
        izq = take mitad xs --Obtenemos los valores de la derecha
        der = drop mitad xs --Obtenemos los valores de la derecha
