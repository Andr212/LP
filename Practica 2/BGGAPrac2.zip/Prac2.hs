
data Fracciones = Fr Int Int deriving (Eq)

instance Show Fracciones where
    show (Fr a b) = show a ++ "/" ++ show b
-- Función para convertir caracteres en espacios
convertirCaracter c
  | c == ',' || c == '/' = ' '
  | otherwise = c

-- Función para procesar la cadena de entrada
procesarContenido contenido = map read (words (map convertirCaracter contenido))

fracEgip (Fr numerador denominador)
    | numerador == 1 = [Fr 1 denominador]
    | denominador `mod` numerador == 0 = [Fr 1 (denominador `div` numerador)]
    | otherwise = Fr 1 ((denominador `div` numerador) + 1) : fracEgip (Fr (numerador * ((denominador `div` numerador) + 1) - denominador) (denominador * ((denominador `div` numerador) + 1)))

msj archivotxt = do
    contenido <- readFile archivotxt
    let numeros = procesarContenido contenido--Esto es para que pueda leer los datos de la forma "a/b" o "a,b"
    putStrLn $ "Los datos leídos: " ++ show numeros
    menu numeros

menu :: [Int] -> IO ()
menu numeros = do
    putStrLn "Eliga una de las siguientes opciones:"
    putStrLn "1. De fracción a fracción egipcia"
    putStrLn "2. Leer una fraccion de un archivo y convertirla a Fraccion Egipcia"
    putStrLn "3. Salir"
    opcion <- getLine
    case opcion of
        "1" -> do
            putStrLn "Ingresa el numerador: " --printf("Ingresa el numerador: ")
            numerador <- readLn :: IO Int-- scanf("%d",&numerador)            
            putStrLn "Ingresa el denominador: " --printf("Ingresa el denominador: ")
            denominador <- readLn :: IO Int-- scanf("%d",&denominador)
            let resultado = fracEgip (Fr (fromIntegral numerador) (fromIntegral denominador))--resultado = fracEgip(numerador,denominador)
            putStrLn $ "La fracción es: " ++ show numerador ++ "/" ++ show denominador--printf("La fracción es: %d/%d",numerador,denominador)
            putStrLn $ "El resultado es: " ++ show resultado
            escribir $ unwords $ map show resultado
            menu numeros
        "2" -> do
            let numedeno = Fr (head numeros) (last numeros) 
                resultado = fracEgip numedeno
            putStrLn $ "La fracción en en el archivo es: " ++ show numedeno       
            putStrLn $ "La fraccion Egipcia quedaria: " ++ show resultado
            escribir $ unwords $ map show resultado
            menu numeros
        
        "3" -> return ()
        _   -> do
            putStrLn "Opción inválida. Intente de nuevo."
            menu numeros
        

main :: IO ()
main = do
    msj "datos.txt"

escribir :: String -> IO ()
escribir resultado = do
    writeFile "resultados.txt" resultado--Crea un archivo llamado resultados.txt y aguarda los valores
    putStrLn "Datos guardados en el archivo resultados.txt"
